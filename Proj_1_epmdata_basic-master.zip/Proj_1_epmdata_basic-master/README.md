# my_epmdata_hdi_project

-- This is an MTA project, which only holds HDI artifacts build with sample data of epm(enterprise procurment model).
-- It is very small one, good one to start with.
-- data is stored in csv files, table structured created with hdbcds models.
-- hdbtabledata files are used to load the data into CDS tables sourced from csv files.

-- it is a very small subset of epm model from HANA SHINE content.

-- Just adjused the naming convention

-- It has the artificats for SQL DDL also, which are created as design time objects, then loaded with simple inserts.

-- both SQL DDL and CDS are updated.
